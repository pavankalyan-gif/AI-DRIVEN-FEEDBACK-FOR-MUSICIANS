# 🎵 AI Music Feedback
**Intelligent Music Practice Intelligence — Cross-Platform**
Virtuoso Learning Ltd × Univerworx | Archie Maclennan | archie@virtuosoapp.io

---

## 🚀 Quick Start

### Linux / Kali
```bash
chmod +x run.sh
./run.sh
```

### Windows (double-click or Command Prompt)
```bat
run.bat
```

### Windows (PowerShell — recommended)
```powershell
# Allow scripts once (if needed):
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

.\run.ps1
```

---

## 📁 Dataset Setup (Optional — runs with synthetic data without it)

Place your 3 datasets inside `datasets/` **before** running:

```
AI_MUSIC_FEEDBACK/
└── datasets/
    ├── nsynth_parquet/          ← NSynth Arrow cache files
    │   └── confit___nsynth-parquet/...
    ├── maestro_v3/              ← MAESTRO v3.0.0
    │   ├── maestro-v3.0.0.csv
    │   └── maestro-v3.0.0/     ← extracted MIDI (2004, 2006, ...)
    └── GuitarSet/               ← GuitarSet
        ├── annotation/          ← .jams files
        └── audio_mono-mic/      ← *_mic.wav files
```

If any dataset is missing the system **automatically falls back to synthetic data** and still runs completely.

---

## 🖥️ Cross-Platform Compatibility

| Feature | Linux/Kali | Windows |
|---|---|---|
| `run.sh` | ✅ | ❌ (use run.bat) |
| `run.bat` | ❌ (use run.sh) | ✅ |
| `run.ps1` | ❌ | ✅ (PowerShell) |
| Python pipeline | ✅ | ✅ |
| All visualizations | ✅ | ✅ |
| Gradio demo | ✅ | ✅ |
| Tests | ✅ | ✅ |

**Windows requirements:**
- Python 3.9+ from https://python.org (check "Add to PATH")
- Internet for package installation
- No WSL required

---

## 📊 Visualizations (outputs/plots/)

| # | File | Content |
|---|---|---|
| 01 | `01_dataset_overview.png` | Sample counts, skill/instrument/source distributions |
| 02 | `02_correlation_heatmap.png` | Feature correlation matrix |
| 03 | `03_quality_scorer_analysis.png` | Actual vs predicted, residuals, MAE/R² bars |
| 04 | `04_skill_classifier_analysis.png` | Confusion matrix (raw + normalised), P/R/F1 |
| 05 | `05_feature_importance.png` | Top-20 features for both models |
| 06 | `06_model_comparison.png` | Model performance dashboard + summary card |
| 07 | `07_acoustic_features.png` | MFCC heatmap, chroma, spectral boxplots, violins |
| 08 | `08_alignment_analysis.png` | Student vs teacher alignment distribution |
| 09 | `09_dataset_source_comparison.png` | Feature boxplots per dataset source |
| 10 | `10_summary_dashboard.png` | Master KPI dashboard |

---

## 🏗️ Project Structure

```
AI_MUSIC_FEEDBACK/
├── run.sh                       ← Linux/Kali entry point
├── run.bat                      ← Windows entry point
├── run.ps1                      ← Windows PowerShell entry point
├── requirements.txt
├── README.md
├── src/
│   ├── paths.py                 ← Cross-platform path resolver
│   ├── data_loader.py           ← NSynth + MAESTRO + GuitarSet + Synthetic
│   ├── audio_features/
│   │   └── extractor.py         ← librosa 60+ feature extraction
│   ├── ml_model/
│   │   └── model.py             ← GradientBoosting + RandomForest + CV
│   ├── visualizations/
│   │   └── charts.py            ← 10 matplotlib/seaborn charts
│   ├── feedback/
│   │   └── feedback.py          ← NLP comparator + feedback generator
│   ├── pipeline/
│   │   └── pipeline.py          ← End-to-end orchestrator
│   └── demo/
│       └── demo.py              ← Gradio 5-tab app (port 7861)
├── datasets/                    ← PUT YOUR DATASETS HERE
│   ├── nsynth_parquet/
│   ├── maestro_v3/
│   └── GuitarSet/
├── data/
│   ├── processed/               ← Parquet feature tables
│   └── models/                  ← Saved .pkl models + JSON metrics
├── outputs/
│   ├── plots/                   ← 10 PNG visualizations
│   └── sample_feedback_report.txt
└── tests/
    └── test_all.py              ← 35 unit tests
```

---

## 🎭 Gradio Demo (5 Tabs)

Launch: open browser at **http://localhost:7861** after running.

| Tab | Function |
|---|---|
| 🎧 Audio Analysis | Upload audio → pitch, quality score, 60+ features |
| 🔄 Feedback Comparison | Student vs teacher NLP alignment |
| 📝 Practice Logger | Log session → structured feedback + JSON |
| 📊 Visualizations | Browse all 10 training charts |
| 🖥️ Dashboard | Dataset stats + model metrics + alignment |

---

## ⚡ Run Options

```bash
# Linux
./run.sh              # full pipeline + demo
./run.sh --pipeline   # pipeline only (no demo)
./run.sh --demo-only  # demo only (skip pipeline)

# Windows
run.bat
run.bat --pipeline
run.bat --demo-only

# PowerShell
.\run.ps1
.\run.ps1 --pipeline
.\run.ps1 --demo-only
```

---

## 🤖 Model Performance

| Model | Algorithm | Target | Typical Performance |
|---|---|---|---|
| Quality Scorer | GradientBoosting (200 trees) | Quality score 0–100 | MAE ≈ 3–8 pts, R² ≈ 0.83–0.96 |
| Skill Classifier | RandomForest (300 trees) | Beginner/Intermediate/Advanced | Accuracy ≈ 95–99% |

5-fold cross-validation included. Full metrics → `data/models/model_summary.json`.

---

*AI Music Feedback · Virtuoso Learning Ltd · 2026*
