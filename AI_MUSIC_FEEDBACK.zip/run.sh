#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  AI MUSIC FEEDBACK — Linux/Kali Run Script
#
#  DATASETS: Place inside the datasets/ folder before running:
#    datasets/nsynth_parquet/    ← NSynth Arrow cache
#    datasets/maestro_v3/        ← MAESTRO CSV + MIDI
#    datasets/GuitarSet/         ← annotation/ + audio_mono-mic/
#
#  Usage:
#    chmod +x run.sh
#    ./run.sh              ← full pipeline + demo
#    ./run.sh --demo-only  ← skip pipeline, just launch demo
#    ./run.sh --pipeline   ← pipeline only, no demo
# ═══════════════════════════════════════════════════════════════

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

MODE="full"
if [[ "$1" == "--demo-only" ]]; then MODE="demo"; fi
if [[ "$1" == "--pipeline" ]];  then MODE="pipeline"; fi

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║       AI MUSIC FEEDBACK — Linux/Kali                    ║"
echo "║  NSynth + MAESTRO v3 + GuitarSet + Visualizations       ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# ── Dataset check ──────────────────────────────────────────────
echo "[check] datasets/ contents:"
ls datasets/ 2>/dev/null && echo "" || echo "  (empty — synthetic data will be used)"

# ── Install dependencies ───────────────────────────────────────
echo "[1/4] Installing dependencies..."
pip install -q librosa soundfile scikit-learn gradio music21 oemer opencv-python-headless Pillow midiutil \
    sentence-transformers pandas numpy pyarrow \
    matplotlib seaborn datasets jams pretty_midi \
    --break-system-packages 2>&1 | tail -3
echo ""

if [[ "$MODE" != "demo" ]]; then
    # ── Run pipeline ───────────────────────────────────────────
    echo "[2/4] Running full pipeline..."
    cd src && python3 pipeline/pipeline.py
    cd "$SCRIPT_DIR"

    # ── Run tests ──────────────────────────────────────────────
    echo "[3/4] Running tests..."
    cd src && python3 -m pytest ../tests/test_all.py -v --tb=short 2>/dev/null \
        || python3 ../tests/test_all.py
    cd "$SCRIPT_DIR"
else
    echo "[2/4] Skipping pipeline (--demo-only mode)"
    echo "[3/4] Skipping tests"
fi

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  ✓ Pipeline complete                                     ║"
echo "║  Plots  : outputs/plots/  (10 PNG files)                ║"
echo "║  Report : outputs/sample_feedback_report.txt            ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

if [[ "$MODE" != "pipeline" ]]; then
    echo "[4/4] Launching Gradio demo → http://localhost:7861"
    echo "      Press Ctrl+C to stop."
    echo ""
    cd src && python3 demo/demo.py
fi
