"""
AI Music Feedback — Gradio Demo (Cross-Platform)
Works on Linux (Kali) and Windows.
8 Tabs:
  1. Audio Analysis
  2. Feedback Comparison
  3. Practice Logger
  4. Sheet Music Upload
  5. MusicXML & Events
  6. Score & MIDI
  7. Visualizations
  8. Dashboard
"""
import sys, json, warnings, time
import numpy as np, pandas as pd
import gradio as gr
from pathlib import Path
warnings.filterwarnings("ignore")

_src = Path(__file__).resolve().parent.parent
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from paths import (ROOT, PLOTS_DIR, PROCESSED_DIR, OUTPUTS_DIR,
                   MODELS_DIR, is_windows)
from audio_features.extractor import AudioFeatureExtractor
from feedback.feedback import FeedbackComparator, FeedbackGenerator
from sheet_music.sheet_processor import (
    image_to_musicxml, parse_musicxml,
    render_score_image, render_bar_range,
    musicxml_to_midi, midi_to_wav
)

MANIFEST_PATH  = ROOT / "data" / "manifest.json"
MODEL_SUM_PATH = MODELS_DIR / "model_summary.json"
SHEET_DIR      = OUTPUTS_DIR / "sheet_music"

print("Loading AI Music Feedback components...")
extractor  = AudioFeatureExtractor()
comparator = FeedbackComparator()
generator  = FeedbackGenerator()

logs_df   = pd.read_parquet(PROCESSED_DIR/"practice_logs.parquet") \
            if (PROCESSED_DIR/"practice_logs.parquet").exists() else pd.DataFrame()
manifest  = json.loads(MANIFEST_PATH.read_text(encoding="utf-8")) \
            if MANIFEST_PATH.exists() else {}
model_sum = json.loads(MODEL_SUM_PATH.read_text(encoding="utf-8")) \
            if MODEL_SUM_PATH.exists() else {}
session_store = []

# Sheet music session state
sheet_state = {
    "uploaded_path": None,
    "musicxml_path": None,
    "events":        [],
    "stats":         {},
    "midi_path":     None,
    "wav_path":      None,
}

NOTES = [""] + [f"{n}{o}" for o in range(2,7)
                for n in ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]]
FOCUS = ["Scales and arpeggios","Sight reading","Dynamics control",
         "Tempo consistency","Articulation","Pedal technique",
         "Hand coordination","Memory work","Expression","Rhythm accuracy"]

print("  ✓ Ready")

# ── TAB 1: AUDIO ANALYSIS ─────────────────────────────────────
def analyze_audio(audio_file, target_note):
    if audio_file is None:
        return "Please upload an audio file.", "{}", "No audio provided."
    try:
        feat = extractor.extract(audio_file)
        fb   = extractor.generate_feedback_string(feat, target_note=target_note or None)
        display = {
            "Quality Score":        f"{feat.get('quality_score',0):.1f} / 100",
            "Detected Note":        feat.get("detected_note","N/A"),
            "Pitch Accuracy":       f"{feat.get('pitch_accuracy',0)*100:.1f}%",
            "In Tune":              "✓ Yes" if feat.get("pitch_in_tune") else "✗ No",
            "Pitch Deviation":      f"{feat.get('pitch_cents_deviation',0):+.1f} cents",
            "Tempo":                f"{feat.get('tempo',0):.0f} BPM",
            "Loudness Consistency": f"{feat.get('loudness_consistency',0)*100:.1f}%",
            "Spectral Centroid":    f"{feat.get('spectral_centroid',0):.0f} Hz",
            "RMS Energy":           f"{feat.get('rms_energy_mean',0):.4f}",
            "Duration":             f"{feat.get('duration_sec',0):.2f} s",
        }
        tbl = "| Feature | Value |\n|---|---|\n" + \
              "".join(f"| {k} | {v} |\n" for k,v in display.items())
        raw = json.dumps({k:v for k,v in feat.items()
                          if isinstance(v,(int,float,str,bool))}, indent=2)
        return tbl, raw, fb
    except Exception as e:
        return f"Error: {e}", "{}", str(e)

# ── TAB 2: FEEDBACK COMPARISON ────────────────────────────────
def compare_feedback(student, teacher):
    if not student.strip() or not teacher.strip():
        return "Please enter both texts.", ""
    result = comparator.compare_session(student, teacher)
    score  = result["similarity_score"]
    aln    = result["alignment"]
    icon   = {"HIGH":"🟢","MODERATE":"🟡","LOW":"🔴"}.get(aln,"⚪")
    out    = f"""## {icon} Alignment: {aln}
**Similarity Score:** {score:.0%}
**Interpretation:** {result['interpretation']}
Student words: {result['student_word_count']} | Teacher words: {result['teacher_word_count']}"""
    tips = generator.generate(
        session_data={"student_rating":6,"teacher_rating":6,"piece":"Current"},
        comparison_result=result)
    tips_md = "\n".join(f"- {t}" for t in tips.get("actionable_tips",[]))
    return out, f"### 💡 Tips\n{tips_md}"

def random_session():
    valid = logs_df.dropna(subset=["student_self_report","teacher_feedback"]) \
            if "student_self_report" in logs_df.columns else pd.DataFrame()
    if len(valid):
        r = valid.sample(1).iloc[0]
        return str(r.get("student_self_report","")), str(r.get("teacher_feedback",""))
    return ("Practised Nocturne for 30 min. Left hand improving.",
            "Good effort. Dynamics in section B need work.")

# ── TAB 3: PRACTICE LOGGER ───────────────────────────────────
def log_session(piece, focus, duration, report_txt, rating, audio_file):
    if not piece.strip() or not report_txt.strip():
        return "Please fill in Piece and Self-Report.", ""
    session = {"session_id":f"SESS_{len(session_store):04d}","piece":piece,
               "focus_area":focus,"duration_min":int(duration),
               "student_self_report":report_txt,"student_rating":int(rating),
               "teacher_rating":None,"teacher_feedback":""}
    af = None
    if audio_file:
        try: af = extractor.extract(audio_file)
        except: pass
    fb = generator.generate(audio_features=af, session_data=session)
    session["feedback"] = fb
    session_store.append(session)
    report = generator.format_for_display(fb)
    js_out = json.dumps({"session":{k:v for k,v in session.items() if k!="feedback"},
                         "feedback":fb,"audio_features":{k:v for k,v in (af or {}).items()
                         if isinstance(v,(int,float,str,bool))}}, indent=2, default=str)
    return report, js_out

# ── TAB 4: SHEET MUSIC UPLOAD ────────────────────────────────
def upload_sheet_music(file):
    if file is None:
        return "Please upload a sheet music file.", "", ""
    path = Path(file)
    size_mb = round(path.stat().st_size / 1024 / 1024, 2)
    sheet_state["uploaded_path"] = str(path)
    sheet_state["musicxml_path"] = None
    sheet_state["events"]        = []
    sheet_state["stats"]         = {}
    return (f"✅ Sheet music file uploaded successfully.",
            f"Uploaded file: {path.name}",
            f"File size: {size_mb} MB")

def convert_to_musicxml():
    if not sheet_state["uploaded_path"]:
        return "❌ Please upload a sheet music file first.", ""
    out_name = f"{Path(sheet_state['uploaded_path']).stem}_{int(time.time())}"
    result = image_to_musicxml(sheet_state["uploaded_path"], out_name)
    if result["success"]:
        sheet_state["musicxml_path"] = result["musicxml_path"]
        # Auto-parse
        parsed = parse_musicxml(result["musicxml_path"])
        if parsed["success"]:
            sheet_state["events"] = parsed["events"]
            sheet_state["stats"]  = parsed["stats"]
        return (f"✅ {result['message']}",
                f"Parts: {sheet_state['stats'].get('parts',0)}  |  "
                f"Measures: {sheet_state['stats'].get('measures',0)}  |  "
                f"Notes: {sheet_state['stats'].get('notes',0)}")
    else:
        return f"❌ {result['message']}", ""

# ── TAB 5: MUSICXML & EVENTS ─────────────────────────────────
def get_events_table():
    if not sheet_state["events"]:
        return "No events — upload a sheet music file and convert first.", None
    events = sheet_state["events"]
    stats  = sheet_state["stats"]
    header = f"""### MusicXML Processing
**Parts:** {stats.get('parts',0)} | **Measures:** {stats.get('measures',0)} | **Notes:** {stats.get('notes',0)} | **BPM:** {stats.get('bpm',120)}
"""
    rows = [["Measure","Beat","Time (s)","Note","Octave","Duration","Duration Name"]]
    for e in events[:100]:  # show first 100
        rows.append([
            str(e["measure"]), str(e["beat"]), str(e["time_sec"]),
            e["note"], str(e["octave"]), str(e["duration"]), e["dur_name"]
        ])
    return header, rows

def download_events_csv():
    if not sheet_state["events"]:
        return None
    import tempfile, csv
    tmp = tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode="w", newline="")
    w   = csv.DictWriter(tmp, fieldnames=["part","measure","beat","time_sec",
                                           "note","octave","duration","dur_name"])
    w.writeheader()
    w.writerows(sheet_state["events"])
    tmp.close()
    return tmp.name

def get_bar_range_info():
    if not sheet_state["stats"]:
        return "No score loaded yet.", 1, 1, 1
    n_measures = sheet_state["stats"].get("measures", 1)
    return (f"Available bars: 1 to {n_measures}",
            1, n_measures, n_measures)

# ── TAB 6: SCORE & MIDI ──────────────────────────────────────
def visualize_score():
    if not sheet_state["musicxml_path"]:
        return None, "No MusicXML loaded. Upload and convert a sheet music file first."
    out_name = f"score_{int(time.time())}"
    result = render_score_image(sheet_state["musicxml_path"], out_name)
    if result["success"]:
        return result["image_path"], "✅ Score visualised successfully."
    return None, f"❌ {result['message']}"

def visualize_bar_range(start_bar, end_bar):
    if not sheet_state["musicxml_path"]:
        return None, "No MusicXML loaded."
    result = render_bar_range(sheet_state["musicxml_path"],
                              int(start_bar), int(end_bar))
    if result["success"]:
        return (result["image_path"],
                f"✅ Bars {int(start_bar)}–{int(end_bar)} | {result['note_count']} notes")
    return None, f"❌ {result['message']}"

def generate_midi():
    if not sheet_state["musicxml_path"]:
        return None, None, "No MusicXML loaded. Convert a sheet music file first."
    out_name = f"midi_{int(time.time())}"
    midi_res = musicxml_to_midi(sheet_state["musicxml_path"], out_name)
    if not midi_res["success"]:
        return None, None, f"❌ MIDI: {midi_res['message']}"
    sheet_state["midi_path"] = midi_res["midi_path"]
    # Convert to WAV for playback
    wav_res = midi_to_wav(midi_res["midi_path"], out_name)
    if wav_res["success"]:
        sheet_state["wav_path"] = wav_res["wav_path"]
        return (wav_res["wav_path"], midi_res["midi_path"],
                f"✅ MIDI file created successfully. Duration: {midi_res.get('size_kb',0)} KB")
    return None, midi_res["midi_path"], f"✅ MIDI created. WAV synthesis: {wav_res.get('message','failed')}"

# ── TAB 7: VISUALIZATIONS ────────────────────────────────────
def get_plot_images():
    if not PLOTS_DIR.exists():
        return [], "No plots found. Run the pipeline first."
    plots = sorted(PLOTS_DIR.glob("*.png"))
    if not plots:
        return [], "No plots found. Run: python src/pipeline/pipeline.py"
    return [str(p) for p in plots], f"✓ {len(plots)} plots available"

# ── TAB 8: DASHBOARD ─────────────────────────────────────────
def get_dashboard():
    qs = model_sum.get("quality_scorer",{})
    sc = model_sum.get("skill_classifier",{})
    platform_str = "Windows" if is_windows() else "Linux"
    md = f"""## 📊 AI Music Feedback — Dashboard ({platform_str})

### 🎼 Datasets
| Dataset | Samples |
|---|---|
| NSynth | **{manifest.get('nsynth_samples',0)}** |
| MAESTRO v3.0.0 | **{manifest.get('maestro_samples',0)}** |
| GuitarSet | **{manifest.get('guitarset_samples',0)}** |
| Synthetic | **{manifest.get('synthetic_audio',0)}** |
| **Total** | **{manifest.get('total_audio',0)} audio + {manifest.get('total_logs',0)} logs** |

### 🤖 Model Performance
| Model | Performance |
|---|---|
| Quality Scorer (GBR) | MAE={qs.get('test_mae',0):.2f} · R²={qs.get('test_r2',0):.3f} |
| Skill Classifier (RF) | Accuracy={sc.get('accuracy',0)*100:.1f}% |

### 🎵 Sheet Music Sessions: **{1 if sheet_state['musicxml_path'] else 0}** loaded
### 🎯 Practice Sessions: **{len(session_store)}** logged"""
    return md

def get_alignment():
    comp_path = PROCESSED_DIR/"feedback_comparisons.parquet"
    if not comp_path.exists():
        return "Run the pipeline first to generate alignment data."
    df  = pd.read_parquet(comp_path)
    col = "computed_similarity" if "computed_similarity" in df.columns else "alignment_score"
    sc  = df[col].dropna()
    hi  = (sc>0.75).sum(); mod=((sc>=0.45)&(sc<=0.75)).sum(); lo=(sc<0.45).sum(); n=len(sc)
    return f"""## 🔄 Feedback Alignment
| Category | Count | % |
|---|---|---|
| 🟢 HIGH | {hi} | {hi/n*100:.1f}% |
| 🟡 MODERATE | {mod} | {mod/n*100:.1f}% |
| 🔴 LOW | {lo} | {lo/n*100:.1f}% |
**Mean:** {sc.mean():.3f} · **Std:** {sc.std():.3f}"""

# ── BUILD GRADIO APP ──────────────────────────────────────────
def build_demo():
    with gr.Blocks(
        title="AI Music Feedback",
        theme=gr.themes.Soft(primary_hue="violet"),
    ) as demo:

        gr.Markdown("""
# 🎵 AI Music Feedback — Intelligent Practice Intelligence
**Audio Analysis · NLP Feedback · Sheet Music OMR · MIDI Generation**
NSynth · MAESTRO v3 · GuitarSet · oemer · music21 · sentence-transformers
---""")

        with gr.Tabs():

            # ── Tab 1: Audio Analysis ──────────────────────
            with gr.TabItem("🎧 Audio Analysis"):
                gr.Markdown("Upload any audio recording → pitch accuracy, quality score, 60+ features.")
                with gr.Row():
                    with gr.Column(scale=1):
                        audio_in = gr.Audio(label="Upload Audio (WAV/MP3)", type="filepath")
                        note_in  = gr.Dropdown(choices=NOTES, label="Target Note (optional)", value="")
                        an_btn   = gr.Button("🔍 Analyse", variant="primary")
                    with gr.Column(scale=2):
                        feat_tbl = gr.Markdown()
                        fb_txt   = gr.Textbox(label="Feedback", lines=9, interactive=False)
                        raw_json = gr.Code(label="Raw Feature JSON", language="json", lines=10)
                an_btn.click(analyze_audio, [audio_in, note_in], [feat_tbl, raw_json, fb_txt])

            # ── Tab 2: Feedback Comparison ─────────────────
            with gr.TabItem("🔄 Feedback Comparison"):
                gr.Markdown("Compare student self-report vs teacher feedback using NLP.")
                with gr.Row():
                    with gr.Column():
                        stu_in  = gr.Textbox(label="Student Self-Report", lines=5)
                        tch_in  = gr.Textbox(label="Teacher Feedback", lines=5)
                        with gr.Row():
                            cmp_btn = gr.Button("🔍 Compare", variant="primary")
                            rnd_btn = gr.Button("🎲 Load Sample")
                    with gr.Column():
                        cmp_out  = gr.Markdown()
                        tips_out = gr.Markdown()
                cmp_btn.click(compare_feedback, [stu_in, tch_in], [cmp_out, tips_out])
                rnd_btn.click(random_session, [], [stu_in, tch_in])

            # ── Tab 3: Practice Logger ─────────────────────
            with gr.TabItem("📝 Practice Logger"):
                gr.Markdown("Log a practice session and receive AI-generated feedback.")
                with gr.Row():
                    with gr.Column(scale=1):
                        piece_in = gr.Textbox(label="Piece / Exercise", placeholder="e.g. Nocturne Op.9 No.2")
                        focus_in = gr.Dropdown(choices=FOCUS, label="Focus Area", value="Dynamics control")
                        dur_in   = gr.Slider(5, 120, value=30, step=5, label="Duration (min)")
                        rep_in   = gr.Textbox(label="Your Self-Report", lines=4,
                            placeholder="Describe what you worked on...")
                        rat_in   = gr.Slider(1, 10, value=6, step=1, label="Self-Rating (1–10)")
                        rec_in   = gr.Audio(label="Optional Recording", type="filepath")
                        log_btn  = gr.Button("📤 Log Session", variant="primary")
                    with gr.Column(scale=2):
                        rep_out = gr.Textbox(label="Feedback Report", lines=22, interactive=False)
                        js_out  = gr.Code(label="Session JSON", language="json", lines=16)
                log_btn.click(log_session,
                    [piece_in, focus_in, dur_in, rep_in, rat_in, rec_in],
                    [rep_out, js_out])

            # ── Tab 4: Sheet Music Upload ──────────────────
            with gr.TabItem("🎼 Sheet Music Upload"):
                gr.Markdown("""### Upload Sheet Music — PDF, PNG, JPG, JPEG
Upload your sheet music image. The system will detect notes using computer vision (oemer OMR)
and convert to MusicXML format for further processing.""")
                with gr.Row():
                    with gr.Column(scale=1):
                        sheet_file = gr.File(
                            label="Upload Sheet Music PDF/PNG/JPG",
                            file_types=[".pdf",".png",".jpg",".jpeg"])
                        upload_status = gr.Markdown()
                        upload_info1  = gr.Markdown()
                        upload_info2  = gr.Markdown()

                        gr.Markdown("---")
                        gr.Markdown("### MusicXML Conversion")
                        convert_btn    = gr.Button("🎵 Convert to MusicXML", variant="primary",
                                                    elem_id="convert-btn")
                        convert_status = gr.Markdown()
                        convert_info   = gr.Markdown()

                        gr.Markdown("---")
                        gr.Markdown("### Dashboard Workflow")
                        gr.Markdown("""
**1. Upload Sheet Music**
Select a PDF, PNG, JPG, or JPEG file.

**2. Convert and Extract**
Convert the score and identify musical events.

**3. Visualise and Play**
View score information and create MIDI playback.
""")

                sheet_file.change(upload_sheet_music, [sheet_file],
                                  [upload_status, upload_info1, upload_info2])
                convert_btn.click(convert_to_musicxml, [],
                                  [convert_status, convert_info])

            # ── Tab 5: MusicXML & Events ───────────────────
            with gr.TabItem("📋 MusicXML & Events"):
                gr.Markdown("### Recognised Musical Events — Measure, Beat, Note, Duration")
                with gr.Row():
                    extract_btn  = gr.Button("📊 Extract Musical Data", variant="primary")
                    download_btn = gr.Button("⬇️ Download as CSV")
                events_header = gr.Markdown()
                events_table  = gr.Dataframe(
                    headers=["Measure","Beat","Time (s)","Note","Octave","Duration","Duration Name"],
                    interactive=False, wrap=True)
                download_file = gr.File(label="Download Musical Data CSV", visible=False)

                gr.Markdown("---")
                gr.Markdown("### Bar Identification")
                bar_info_md = gr.Markdown()
                with gr.Row():
                    start_bar = gr.Number(label="Start Bar", value=1, minimum=1, precision=0)
                    end_bar   = gr.Number(label="End Bar",   value=14, minimum=1, precision=0)
                selected_bars_md = gr.Markdown()

                def do_extract():
                    header, rows = get_events_table()
                    return header, rows

                def do_bar_select(s, e):
                    n = max(0, int(e) - int(s) + 1)
                    return f"**Selected bars:** {n}"

                extract_btn.click(do_extract, [], [events_header, events_table])

                def do_download():
                    f = download_events_csv()
                    return gr.update(value=f, visible=True) if f else gr.update(visible=False)
                download_btn.click(do_download, [], [download_file])
                start_bar.change(do_bar_select, [start_bar, end_bar], [selected_bars_md])
                end_bar.change(do_bar_select, [start_bar, end_bar], [selected_bars_md])

            # ── Tab 6: Score & MIDI ────────────────────────
            with gr.TabItem("🎹 Score & MIDI"):
                gr.Markdown("### MusicXML Visualisation + MIDI Playback")

                with gr.Row():
                    with gr.Column(scale=1):
                        gr.Markdown("#### Score Visualisation")
                        viz_btn      = gr.Button("🎼 Visualise Full Score", variant="primary")
                        viz_status   = gr.Markdown()

                        gr.Markdown("#### Bar Range View")
                        with gr.Row():
                            viz_start = gr.Number(label="Start Bar", value=1,  minimum=1, precision=0)
                            viz_end   = gr.Number(label="End Bar",   value=14, minimum=1, precision=0)
                        range_btn    = gr.Button("🔍 Show Bar Range", variant="secondary")
                        range_status = gr.Markdown()

                    with gr.Column(scale=2):
                        score_img = gr.Image(label="Music Score (Piano Roll View)",
                                             type="filepath", interactive=False)

                with gr.Row():
                    with gr.Column():
                        gr.Markdown("#### Reference Music Playback")
                        midi_btn    = gr.Button("▶️ Generate & Play MIDI", variant="primary")
                        midi_status = gr.Markdown()
                        audio_player = gr.Audio(label="MIDI Playback", type="filepath",
                                                interactive=False)

                    with gr.Column():
                        gr.Markdown("#### Download Files")
                        midi_file   = gr.File(label="Download MIDI", visible=False)
                        gr.Markdown("*MIDI and WAV files generated from your sheet music using music21.*")

                        gr.Markdown("#### Score Information")
                        score_info  = gr.Markdown()

                def do_visualise():
                    img, msg = visualize_score()
                    stats = sheet_state.get("stats", {})
                    info  = (f"**Parts:** {stats.get('parts',0)} | "
                             f"**Measures:** {stats.get('measures',0)} | "
                             f"**Notes:** {stats.get('notes',0)}")
                    return img, msg, info

                def do_range(s, e):
                    img, msg = visualize_bar_range(int(s), int(e))
                    return img, msg

                def do_midi():
                    wav, mid, msg = generate_midi()
                    midi_update = gr.update(value=mid, visible=mid is not None)
                    return wav, midi_update, msg

                viz_btn.click(do_visualise, [], [score_img, viz_status, score_info])
                range_btn.click(do_range, [viz_start, viz_end], [score_img, range_status])
                midi_btn.click(do_midi, [], [audio_player, midi_file, midi_status])

            # ── Tab 7: Visualizations ──────────────────────
            with gr.TabItem("📊 Visualizations"):
                gr.Markdown("### All 10 training and testing charts generated by the pipeline.")
                with gr.Row():
                    refresh_btn = gr.Button("🔄 Load Plots", variant="primary")
                    plot_status = gr.Markdown()
                gallery = gr.Gallery(label="Training & Analysis Charts",
                                     columns=2, height=750, object_fit="contain")
                def load_plots():
                    imgs, status = get_plot_images()
                    return imgs, status
                refresh_btn.click(load_plots, [], [gallery, plot_status])
                demo.load(load_plots, [], [gallery, plot_status])

            # ── Tab 8: Dashboard ───────────────────────────
            with gr.TabItem("🖥️ Dashboard"):
                gr.Markdown("### Live dataset, model performance, and session stats.")
                ref2_btn = gr.Button("🔄 Refresh")
                with gr.Row():
                    with gr.Column(): dash_md = gr.Markdown()
                    with gr.Column(): aln_md  = gr.Markdown()
                def refresh_dash():
                    return get_dashboard(), get_alignment()
                ref2_btn.click(refresh_dash, [], [dash_md, aln_md])
                demo.load(refresh_dash, [], [dash_md, aln_md])

        # gr.Markdown(
            # "---\n*AI Music Feedback · Virtuoso Learning Ltd · "
            # "Archie Maclennan · archie@virtuosoapp.io · 2026*")

    return demo


if __name__ == "__main__":
    demo = build_demo()
    SHEET_DIR_STR = str(SHEET_DIR) if SHEET_DIR.exists() else str(OUTPUTS_DIR)
    demo.launch(
        server_name="0.0.0.0",
        server_port=7861,
        share=False,
        allowed_paths=[
            str(PLOTS_DIR),
            str(OUTPUTS_DIR),
            SHEET_DIR_STR,
            str(OUTPUTS_DIR / "sheet_music" / "scores"),
            str(OUTPUTS_DIR / "sheet_music" / "midi"),
        ],
    )
