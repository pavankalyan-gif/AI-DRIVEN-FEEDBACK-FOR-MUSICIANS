"""
AI Music Feedback — Cross-Platform Path Utilities
Works identically on Linux (Kali) and Windows.
All paths use pathlib.Path — never hardcoded separators.
"""
import sys
import os
from pathlib import Path

def get_project_root() -> Path:
    """
    Dynamically finds the project root regardless of:
    - which directory the script is run from
    - whether on Linux or Windows
    - whether inside src/ or at root level
    """
    # Try: walk up from this file until we find the marker file (datasets/ folder)
    current = Path(__file__).resolve().parent
    for _ in range(6):  # max 6 levels up
        if (current / "datasets").exists() and (current / "src").exists():
            return current
        current = current.parent
    # Fallback: assume this file is in src/
    return Path(__file__).resolve().parent.parent

ROOT          = get_project_root()
SRC_DIR       = ROOT / "src"
DATASETS_DIR  = ROOT / "datasets"
DATA_DIR      = ROOT / "data"
PROCESSED_DIR = DATA_DIR / "processed"
MODELS_DIR    = DATA_DIR / "models"
OUTPUTS_DIR   = ROOT / "outputs"
PLOTS_DIR     = OUTPUTS_DIR / "plots"
REPORTS_DIR   = OUTPUTS_DIR / "reports"

NSYNTH_DIR    = DATASETS_DIR / "nsynth_parquet"
MAESTRO_DIR   = DATASETS_DIR / "maestro_v3"
GUITARSET_DIR = DATASETS_DIR / "GuitarSet"

# Ensure all output dirs exist on import
for d in [PROCESSED_DIR, MODELS_DIR, PLOTS_DIR, REPORTS_DIR,
          DATA_DIR/"raw", DATASETS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# Add src to sys.path so imports work from any working directory
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

def is_windows() -> bool:
    return sys.platform.startswith("win")

def is_linux() -> bool:
    return sys.platform.startswith("linux")

def get_python_cmd() -> str:
    """Returns the correct python command for the current OS."""
    return "python" if is_windows() else "python3"

def get_pip_cmd() -> str:
    return "pip" if is_windows() else "pip3"
