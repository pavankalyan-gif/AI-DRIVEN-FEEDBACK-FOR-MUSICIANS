# ═══════════════════════════════════════════════════════════════
#  AI MUSIC FEEDBACK — Windows PowerShell Run Script
#
#  Usage:
#    Right-click → Run with PowerShell
#    OR in PowerShell terminal:
#      .\run.ps1              # full pipeline + demo
#      .\run.ps1 --demo-only  # skip pipeline
#      .\run.ps1 --pipeline   # pipeline only
#
#  If execution policy blocks it, run once:
#    Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
# ═══════════════════════════════════════════════════════════════

param(
    [string]$Mode = "full"
)

if ($args -contains "--demo-only") { $Mode = "demo" }
if ($args -contains "--pipeline")  { $Mode = "pipeline" }

# Move to project root
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

Write-Host ""
Write-Host "+=========================================================+" -ForegroundColor Magenta
Write-Host "|       AI MUSIC FEEDBACK -- Windows PowerShell          |" -ForegroundColor Magenta
Write-Host "|  NSynth + MAESTRO v3 + GuitarSet + Visualizations      |" -ForegroundColor Magenta
Write-Host "+=========================================================+" -ForegroundColor Magenta
Write-Host ""

# ── Check Python ──────────────────────────────────────────────
Write-Host "[check] Python version:" -ForegroundColor Cyan
try {
    $pyver = python --version 2>&1
    Write-Host "  $pyver" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Python not found. Install from https://www.python.org/" -ForegroundColor Red
    Write-Host "Make sure to check 'Add Python to PATH' during installation."
    Read-Host "Press Enter to exit"
    exit 1
}

# ── Dataset check ─────────────────────────────────────────────
Write-Host ""
Write-Host "[check] datasets\ contents:" -ForegroundColor Cyan
if (Test-Path "datasets") {
    $items = Get-ChildItem "datasets" -Name
    if ($items) { $items | ForEach-Object { Write-Host "  $_" } }
    else { Write-Host "  (empty -- synthetic data will be used)" -ForegroundColor Yellow }
} else {
    Write-Host "  datasets\ not found -- synthetic data will be used" -ForegroundColor Yellow
}
Write-Host ""

# ── Install dependencies ──────────────────────────────────────
Write-Host "[1/4] Installing dependencies..." -ForegroundColor Cyan
$packages = @(
    "librosa", "soundfile", "scikit-learn", "gradio",
    "sentence-transformers", "pandas", "numpy", "pyarrow",
    "matplotlib", "seaborn", "datasets", "jams", "pretty_midi"
)
pip install -q @packages
if ($LASTEXITCODE -ne 0) {
    Write-Host "WARNING: Some packages may have failed." -ForegroundColor Yellow
}
Write-Host ""

if ($Mode -ne "demo") {
    # ── Run pipeline ──────────────────────────────────────────
    Write-Host "[2/4] Running full pipeline..." -ForegroundColor Cyan
    Set-Location src
    python pipeline\pipeline.py
    if ($LASTEXITCODE -ne 0) {
        Write-Host "ERROR: Pipeline failed." -ForegroundColor Red
        Set-Location $ProjectRoot
        Read-Host "Press Enter to exit"
        exit 1
    }
    Set-Location $ProjectRoot

    # ── Run tests ─────────────────────────────────────────────
    Write-Host "[3/4] Running tests..." -ForegroundColor Cyan
    Set-Location src
    python -m pytest ..\tests\test_all.py -v --tb=short 2>$null
    if ($LASTEXITCODE -ne 0) {
        python ..\tests\test_all.py
    }
    Set-Location $ProjectRoot
} else {
    Write-Host "[2/4] Skipping pipeline (--demo-only mode)" -ForegroundColor Yellow
    Write-Host "[3/4] Skipping tests" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "+=========================================================+" -ForegroundColor Green
Write-Host "|  Pipeline complete                                      |" -ForegroundColor Green
Write-Host "|  Plots  : outputs\plots\  (10 PNG files)               |" -ForegroundColor Green
Write-Host "|  Report : outputs\sample_feedback_report.txt           |" -ForegroundColor Green
Write-Host "+=========================================================+" -ForegroundColor Green
Write-Host ""

if ($Mode -ne "pipeline") {
    Write-Host "[4/4] Launching Gradio demo..." -ForegroundColor Cyan
    Write-Host "      Open browser at: http://localhost:7861" -ForegroundColor Green
    Write-Host "      Press Ctrl+C to stop." -ForegroundColor Yellow
    Write-Host ""
    Set-Location src
    python demo\demo.py
    Set-Location $ProjectRoot
}
